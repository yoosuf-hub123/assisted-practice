export class Employee {
        id?: number;
        employee_email?:string;
        employee_name?: string;
        employee_salary?: number;
        employee_age?: number;
    }
    export class admin {
        id=1;
        email?: string;
        password?: string;
    }
